"""Independent saved-file comparison; does not import or run any optimizer."""
from hashlib import sha256
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OLD = ROOT.parent / 'island_official_stress_20261101'


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def digest(value):
    return sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def main():
    assert read(ROOT / 'status.json')['status'] == 'COMPLETED'
    provenance = read(ROOT / 'provenance.json')
    for filename, expected in provenance['sha256'].items():
        assert sha256(Path(filename).read_bytes()).hexdigest() == expected, filename
    rows = []
    for case in ('small', 'medium', 'large'):
        current_path = ROOT / f'runs/{case}.json'
        fresh = read(current_path)
        previous = read(OLD / f'runs/{case}/ISLAND80/seed_1.json')
        details = read(ROOT / f'details/{case}.json')
        old_details = read(OLD / f'details/{case}/ISLAND80/seed_1.json')
        check = read(ROOT / f'checks/{case}.json')
        initial = read(OLD / f'initial/{case}/seed_1.json')
        assert check['passed'] and not check['differences']
        assert check['result_sha'] == sha256(current_path.read_bytes()).hexdigest()
        assert fresh['status'] == 'COMPLETED'
        assert fresh['algorithm'] == 'GA_PO' and fresh['hybrid_mechanism'] == 'GA_PO_ISLANDS.v1'
        a, b = fresh['result'], previous['result']
        for key in a:
            if key != 'metrics':
                assert a[key] == b[key], (case, key)
        assert {k: v for k, v in a['metrics'].items() if k != 'runtime_seconds'} == {
            k: v for k, v in b['metrics'].items() if k != 'runtime_seconds'}
        assert details['records'] == old_details['records']
        assert details['dense_trace'] == old_details['dense_trace']
        assert details['records'][:30] == initial['records']
        assert digest([item['vector'] for item in details['records'][:30]]) == initial['initial_sha']
        assert len(details['records']) == a['metrics']['fitness_evaluations'] <= 630
        assert [point['iteration'] for point in a['convergence_history']] == list(range(21))
        assert check['hard_violations'] == check['soft_queries'] == 0
        assert details['decoder_work']['soft_option_scores'] == 0
        assert details['decoder_work']['pattern_features_built'] == 0
        rows.append(dict(case=case, seed=1, quality=[a['best_fitness']['general_quality_score'],
            a['best_fitness']['lecturer_preference_score']], fe=len(details['records']),
            history_points=21, decode_failures=a['metrics']['decode_failed_count'],
            backtracks=a['metrics']['total_decode_backtracks'], hard_violations=0,
            initial_and_all_fe_exact=True, result_and_metrics_exact_except_runtime=True))
    report = dict(passed=True, independent_saved_file_audit=True, new_optimizer_runs=3,
                  source_sha_unchanged=True, rows=rows)
    (ROOT / 'independent_audit.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    lines = ['# D159 — Xác nhận code chính trùng ISLAND80 D155', '',
             'Hoàn tất 3/3 run mới, seed1 đã chọn trước cho ba quy mô; N30/20vòng/cap630.',
             'Tự khởi tạo Random(1), không nạp initial hoặc nghiệm tối ưu đã lưu.', '',
             '| Bộ | Q_general mới = cũ | Q_lecturer mới = cũ | FE | Mốc hội tụ | Decode fail | Backtrack | Hard |',
             '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
    for row in rows:
        lines.append(f"| {row['case']} | {row['quality'][0]:.12f} | {row['quality'][1]:.12f} | "
                     f"{row['fe']} | 21/21 | {row['decode_failures']} | {row['backtracks']} | 0 |")
    lines += ['', 'Cả3 đều bằng **chính xác**, không chỉ bằng các số làm tròn trong bảng:',
        '', '- Quần thể ban đầu và SHA30vector.',
        '- Mỗi vector/fitness/phenotype/components ở tất cả FE thực tế.',
        '- Dense best-so-far trace và toàn bộ21mốc hội tụ.',
        '- Best vector, option indices, fullfitness, entries và mapping/checksum.',
        '- Mọi optimization metric trừ runtime. Runtime không thể yêu cầu bằng nhau.',
        '- Hậu kiểm replay hard0/fullcoverage,0softquery; nguồn/config/data/reference SHA không đổi.',
        '', 'Đợt này chứng minh tích hợp tương đương trên3trường hợp nặng được kiểm, không phải',
        'chạy lại toàn bộ120D155 hoặc bằng chứng ưu thế mới của lai. Không đổi thuật toán, seed,',
        'budget hoặc dữ liệu để làm khớp; giữ nguyên toàn bộ kết quả cũ. Không SQL/commit/push/automation.',
        '', 'Bằng chứng: summary.json,independent_audit.json,checks/,runs/,details/,provenance.json.',
        'Các khác biệt được phép: nhãn ISLAND80 lịch sử → GA_PO production,request_id,',
        'hybrid_mechanism mới và thời gian. Chất lượng/lịch/vết tìm kiếm không khác.']
    (ROOT / 'KET_QUA.md').write_text('\n'.join(lines)+'\n', encoding='utf-8')
    print(json.dumps(report))


if __name__ == '__main__':
    main()
