"""Three fresh production runs; exact comparison to read-only D155 artifacts."""
import argparse
from dataclasses import asdict
from datetime import datetime
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from time import perf_counter, sleep
import traceback

from gapo_timetabling.application import run_contract
from gapo_timetabling.core import decoder, population
from gapo_timetabling.core.constraints import validate_timetable
from gapo_timetabling.core.fitness import calculate_fitness
from gapo_timetabling.core.placement_decoder import PlacementDecoder
from gapo_timetabling.core.snapshot import prepare_snapshot_for_optimization

ROOT = Path(__file__).resolve().parents[1]
CORE = ROOT.parents[1]
HISTORY = ROOT.parent / 'island_official_stress_20261101'
CONFIG = CORE / 'benchmark_configs/stress'
CASES = ('small', 'medium', 'large')
SEED = 1


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def canonical(value):
    return json.loads(json.dumps(value, default=str))


def digest(value):
    return sha256(json.dumps(canonical(value), sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def file_sha(path):
    return sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    # One writer per path; temp never shared between workers.
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(canonical(value), ensure_ascii=False, indent=2), encoding='utf-8')
    for attempt in range(12):
        try:
            temp.replace(path)
            break
        except PermissionError:
            if attempt == 11:
                raise
            sleep(.05 * (attempt + 1))


def identities():
    files = list((CORE / 'src').rglob('*.py')) + [Path(__file__), ROOT / 'PROTOCOL.md']
    for case in CASES:
        files += [CONFIG / f'request_{case}.json', CONFIG / f'data/{case}.json',
                  HISTORY / f'runs/{case}/ISLAND80/seed_1.json',
                  HISTORY / f'details/{case}/ISLAND80/seed_1.json',
                  HISTORY / f'initial/{case}/seed_1.json',
                  HISTORY / f'checkpoints/{case}/ISLAND80/seed_1.json']
    return {str(path): file_sha(path) for path in sorted(files)}


def verify():
    if read(ROOT / 'provenance.json')['sha256'] != identities():
        raise RuntimeError('Source/config/data/reference changed during confirmation.')


def worker(case):
    verify()
    started = perf_counter()
    request = run_contract.load_run_request(CONFIG / f'request_{case}.json')
    assert request.random_seed == SEED and request.ga_ratio == .8
    assert request.population_size == 30 and request.max_fitness_evaluations == 630
    prepared = prepare_snapshot_for_optimization(request.snapshot.path,
                                                expected_checksum=request.snapshot.checksum)
    original = read(HISTORY / f'runs/{case}/ISLAND80/seed_1.json')
    reference = read(HISTORY / f'details/{case}/ISLAND80/seed_1.json')
    initial = read(HISTORY / f'initial/{case}/seed_1.json')
    checkpoint = read(HISTORY / f'checkpoints/{case}/ISLAND80/seed_1.json')
    assert checkpoint['result_sha'] == file_sha(HISTORY / f'runs/{case}/ISLAND80/seed_1.json')
    assert checkpoint['detail_sha'] == file_sha(HISTORY / f'details/{case}/ISLAND80/seed_1.json')
    engine = PlacementDecoder()
    decoder.clear_decode_cache()
    decoder._PRIORITY_LOCAL.decoder = engine
    records, trace = [], []
    real_fitness = population.calculate_fitness
    best = None
    def observe(*args, **kwargs):
        nonlocal best
        value = real_fitness(*args, **kwargs)
        row = dict(vector=list(engine.last_vector), quality=list(value.fitness_key),
                   phenotype=digest(args[1]), components=asdict(value.breakdown))
        records.append(canonical(row))
        if best is None or tuple(row['quality']) < tuple(best):
            best = row['quality']
        trace.append(dict(fe=len(records), best=best.copy()))
        return value
    last_generation = [-1]
    def progress(value):
        if value.iteration != last_generation[0] or value.metrics.fitness_evaluations % 30 == 0:
            last_generation[0] = value.iteration
            try:
                save(ROOT / f'progress/{case}.json', dict(
                    case=case, seed=SEED, iteration=value.iteration,
                    max_iterations=value.max_iterations, metrics=asdict(value.metrics),
                    elapsed_seconds=perf_counter()-started, at=datetime.now().isoformat()))
            except PermissionError:
                pass  # Optional UI progress must not invalidate an optimizer run.
    population.calculate_fitness = observe
    try:
        payload = run_contract.execute_prepared_run_request(request, prepared, progress_callback=progress)
    finally:
        population.calculate_fitness = real_fitness
        decoder.clear_decode_cache()
    save(ROOT / f'runs/{case}.json', payload)
    save(ROOT / f'details/{case}.json', dict(records=records, dense_trace=trace, decoder_work=engine.stats))
    assert payload['status'] == 'COMPLETED', payload
    current, previous = payload['result'], original['result']
    differences = []
    def compare(label, a, b):
        if a != b:
            differences.append(label)
    fresh_initial_sha = digest([row['vector'] for row in records[:30]])
    compare('initial_sha', fresh_initial_sha, initial['initial_sha'])
    compare('initial_records', records[:30], initial['records'])
    compare('every_fe_record', records, reference['records'])
    compare('dense_best_trace', trace, reference['dense_trace'])
    compare('convergence_history', current['convergence_history'], previous['convergence_history'])
    for key in ('best_solution', 'best_fitness', 'timetable_entries',
                'gene_option_mapping', 'gene_option_mapping_checksum'):
        compare(key, current[key], previous[key])
    metrics = {k: v for k, v in current['metrics'].items() if k != 'runtime_seconds'}
    old_metrics = {k: v for k, v in previous['metrics'].items() if k != 'runtime_seconds'}
    compare('metrics_except_runtime', metrics, old_metrics)
    compare('snapshot_checksum', payload['snapshot_checksum'], original['snapshot_checksum'])
    compare('zero_soft_scores', engine.stats['soft_option_scores'], 0)
    solution = current['best_solution']
    replay_engine = PlacementDecoder()
    replay = replay_engine(prepared.problem, prepared.option_domains, tuple(solution['vector']), 20000)
    assert replay.is_success
    validation = validate_timetable(prepared.problem, replay.selected_options)
    compare('hard_violations', len(validation.violations), 0)
    compare('full_coverage', len(replay.selected_options), len(prepared.problem.class_sessions))
    compare('replay_indices', list(replay.selected_option_indices), solution['selected_option_indices'])
    replay_fitness = calculate_fitness(prepared.problem, replay.selected_options, prepared.option_domains)
    compare('replay_quality', list(replay_fitness.fitness_key),
            [current['best_fitness']['general_quality_score'], current['best_fitness']['lecturer_preference_score']])
    verify()
    report = dict(case=case, seed=SEED, passed=not differences, differences=differences,
                  fresh_initial_sha=fresh_initial_sha, old_initial_sha=initial['initial_sha'],
                  exact_fe_records=len(records), exact_history_points=len(current['convergence_history']),
                  quality=trace[-1]['best'], metrics=current['metrics'],
                  hard_violations=len(validation.violations), soft_queries=engine.stats['soft_option_scores'],
                  wall_seconds=perf_counter()-started,
                  result_sha=file_sha(ROOT / f'runs/{case}.json'))
    save(ROOT / f'checks/{case}.json', report)
    if differences:
        raise AssertionError(f'{case}: differences={differences}')
    print(json.dumps(dict(case=case, passed=True, metrics=metrics, quality=report['quality'])), flush=True)


def controller():
    if (ROOT / 'provenance.json').exists():
        raise RuntimeError('Confirmation already exists; do not automatically restart or overwrite.')
    save(ROOT / 'provenance.json', dict(seed=SEED, cases=CASES, sha256=identities(),
                                      started_at=datetime.now().isoformat()))
    processes = {}
    handles = []
    for case in CASES:
        logdir = ROOT / 'logs'
        logdir.mkdir(exist_ok=True)
        stdout = (logdir / f'{case}.stdout.log').open('w', encoding='utf-8')
        stderr = (logdir / f'{case}.stderr.log').open('w', encoding='utf-8')
        handles.extend([stdout, stderr])
        processes[case] = subprocess.Popen([sys.executable, str(Path(__file__)), '--case', case],
                                           stdout=stdout, stderr=stderr, cwd=CORE)
    while True:
        status = {case: proc.poll() for case, proc in processes.items()}
        completed = [case for case, code in status.items() if code == 0]
        failures = [case for case, code in status.items() if code not in (None, 0)]
        running = [case for case, code in status.items() if code is None]
        save(ROOT / 'status.json', dict(status='RUNNING' if running else 'FAILED' if failures else 'COMPLETED',
             completed=completed, failed=failures, running=running,
             workers={case: proc.pid for case, proc in processes.items()}, at=datetime.now().isoformat()))
        if not running:
            break
        sleep(2)
    for handle in handles:
        handle.close()
    if failures:
        raise RuntimeError(f'Confirmation failed: {failures}; no automatic retry.')
    reports = [read(ROOT / f'checks/{case}.json') for case in CASES]
    verify()
    save(ROOT / 'summary.json', dict(passed=all(row['passed'] for row in reports),
                                    new_optimizer_runs=3, cases=reports))
    print('CONFIRMATION_COMPLETE', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--case', choices=CASES)
    args = parser.parse_args()
    try:
        worker(args.case) if args.case else controller()
    except Exception:
        traceback.print_exc()
        sys.exit(1)
