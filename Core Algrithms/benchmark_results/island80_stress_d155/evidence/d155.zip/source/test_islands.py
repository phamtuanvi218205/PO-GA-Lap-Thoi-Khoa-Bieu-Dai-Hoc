"""Pilot invariants, no dependency on long-running benchmark results."""
from dataclasses import asdict
from types import SimpleNamespace
from unittest.mock import patch

import pytest

from islands import run_islands, migrate, unique_best
from gapo_timetabling.core import decoder, po
from gapo_timetabling.core.constraints import validate_timetable
from gapo_timetabling.core.encoder import build_option_domains
from gapo_timetabling.core.hybrid import HybridConfig
from gapo_timetabling.core.population import CandidateEvaluationConfig, initialize_population
from gapo_timetabling.core.placement_decoder import PlacementDecoder
from tests.test_constraints import ConstraintFixture


def inputs():
    f = ConstraintFixture()
    f.setUp()
    p = f.problem
    domains = build_option_domains(p)
    config = CandidateEvaluationConfig(1000, True, 3)
    initial = initialize_population(p, domains, 10, 1000, 481, config)
    assert initial.is_success
    return p, domains, initial, HybridConfig(110, 5, 482, config)


def stable(result):
    value = asdict(result)
    value['metrics'].pop('runtime_seconds')
    return value


def fake(tag, q):
    return SimpleNamespace(vector=(float(tag),), selected_options=(tag,), fitness_key=(q, 0.))


def test_migration_novel_phenotype_protects_best_and_noop_on_duplicates():
    best, worst = fake(1, 0.), fake(2, .5)
    migrant = fake(3, .7)
    result, sent = migrate((migrant,), (best, worst))
    assert sent is migrant and result == (best, migrant)
    assert migrate((best, worst), (best, worst)) == ((best, worst), None)
    assert unique_best((worst, best, best, migrant), 2) == (best, worst)


def test_two_islands_use_full_vector_four_behaviors_and_stay_replayable():
    p, domains, initial, config = inputs()
    original = tuple(i.vector for i in initial.individuals)
    with patch.object(po, 'create_po_position', wraps=po.create_po_position) as positions:
        result, stats = run_islands(p, domains, initial, config)
    assert stats['ga_size'] == 8 and stats['po_size'] == 2
    assert stats['counts']['ga_slots'] == 80 and stats['counts']['po_slots'] == 20
    assert all(count > 0 for count in stats['behaviors'].values())
    assert stats['counts']['po_formula_calls'] == positions.call_count
    for call in positions.call_args_list:
        assert len(call.kwargs['current']) == p.dimension
        assert len(call.kwargs['population_mean']) == p.dimension
        assert len(call.kwargs['best_position']) == p.dimension
    assert result.metrics.fitness_evaluations <= 110
    assert result.metrics.completed_iterations == 10
    assert len(result.final_population) == 10
    assert len(stats['migrations']) == 4
    assert original == tuple(i.vector for i in initial.individuals)
    assert stats['counts']['po_valid_worse_accepted'] > 0
    assert stats['counts']['ga_to_po'] > 0 and stats['counts']['po_to_ga'] > 0
    for item in result.final_population + (result.best_individual,):
        replay = PlacementDecoder()(p, domains, item.vector, 1000)
        assert replay.selected_options == item.selected_options
        assert validate_timetable(p, item.selected_options).is_valid


def test_repeatability_and_random_ablation_does_not_call_po():
    p, domains, initial, config = inputs()
    a, ta = run_islands(p, domains, initial, config)
    b, tb = run_islands(p, domains, initial, config)
    assert stable(a) == stable(b) and ta == tb
    with patch.object(po, '_create_and_evaluate_po_offspring', side_effect=AssertionError('PO')):
        random, tr = run_islands(p, domains, initial, config, random_control=True)
    assert random.metrics.fitness_evaluations <= 110
    assert tr['counts']['po_formula_calls'] == 0 and tr['random_control']


def test_no_soft_queries_and_actual_fe_equals_success_count():
    p, domains, initial, config = inputs()
    engine = PlacementDecoder()
    decoder.clear_decode_cache()
    decoder._PRIORITY_LOCAL.decoder = engine
    try:
        with patch.object(engine, '_score', side_effect=AssertionError('SOFT')):
            result, stats = run_islands(p, domains, initial, config)
        c = stats['counts']
        assert result.metrics.fitness_evaluations == 10+c['ga_success']+c['po_success']
        assert engine.stats['soft_option_scores'] == engine.stats['pattern_features_built'] == 0
    finally:
        decoder.clear_decode_cache()


def test_invalid_small_island_partition_is_rejected():
    from dataclasses import replace
    p, domains, initial, config = inputs()
    small = replace(initial, requested_population_size=5, individuals=initial.individuals[:5],
                    fitness_evaluations=5)
    with pytest.raises(ValueError, match='two'):
        run_islands(p, domains, small, replace(config, max_fitness_evaluations=55))
