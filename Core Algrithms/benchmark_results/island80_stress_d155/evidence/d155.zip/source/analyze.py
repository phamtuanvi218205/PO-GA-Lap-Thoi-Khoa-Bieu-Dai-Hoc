"""Read saved runs only: independent audit, paired comparisons and figures."""
from collections import Counter
from dataclasses import asdict
import csv
from itertools import combinations
import numpy as np
from scipy.stats import binomtest
from statistics import median, pstdev

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from common import (ROOT, DATA, CASES, SEEDS, METHODS, BASELINE, FE_CAP, GENERATIONS, POPULATION, EXPECTED_RUNS, save, read, sha, result_path,
                    detail_path, checkpoint, compare, audit, verify)
from gapo_timetabling.core.snapshot import prepare_snapshot_for_optimization


def quality(payload):
    value = payload['result']['best_fitness']
    return [value['general_quality_score'], value['lecturer_preference_score']]


def at_fe(detail, fe):
    return detail['dense_trace'][fe-1]['best']


def main():
    verify()
    out = ROOT/'analysis'
    rows, pairs, initial_statistics = [], [], []
    results, details = {}, {}
    for case in CASES:
        prepared = prepare_snapshot_for_optimization(DATA/f'data/{case}.json')
        for seed in SEEDS:
            init = read(ROOT/f'initial/{case}/seed_{seed}.json')
            q0 = min((r['quality'] for r in init['records']), key=tuple)
            initial_statistics.append(dict(case=case, seed=seed, initial_sha=init['initial_sha'],
                dimension=init['dimension'], best=q0,
                q_general_std=pstdev(r['quality'][0] for r in init['records']),
                q_lecturer_std=pstdev(r['quality'][1] for r in init['records']),
                unique_phenotypes=len({r['phenotype'] for r in init['records']})))
            for method in METHODS:
                result, detail = read(result_path(case, seed, method)), read(detail_path(case, seed, method))
                check = read(checkpoint(case, seed, method))
                assert check['result_sha'] == sha(result_path(case, seed, method))
                assert check['detail_sha'] == sha(detail_path(case, seed, method))
                assert check['initial_sha'] == detail['initial_sha'] == init['initial_sha']
                assert detail['records'][:POPULATION] == init['records']
                metric = result['result']['metrics']
                assert metric['completed_iterations'] == GENERATIONS and metric['fitness_evaluations'] <= FE_CAP
                assert len(detail['records']) == len(detail['dense_trace']) == metric['fitness_evaluations']
                assert detail['dense_trace'][-1]['best'] == quality(result)
                assert detail['decoder_work']['soft_option_scores'] == 0
                replay = audit(result, prepared)
                results[case, seed, method] = result
                details[case, seed, method] = detail
                rows.append(dict(case=case, seed=seed, method=method, initial=q0, quality=quality(result),
                    improved=compare(quality(result), q0) == 'win',
                    q_general_improved=quality(result)[0] < q0[0]-1e-12,
                    metrics=metric, hard_violations=0, replay_nodes=replay.nodes_explored,
                    decoder_work=detail['decoder_work'], decoder_failure_reasons=detail['decoder_failure_reasons'],
                    contributions=detail['contributions']))
            for a, b in combinations(METHODS, 2):
                ra, rb = results[case, seed, a], results[case, seed, b]
                da, db = details[case, seed, a], details[case, seed, b]
                common = min(ra['result']['metrics']['fitness_evaluations'], rb['result']['metrics']['fitness_evaluations'])
                pairs.append(dict(case=case, seed=seed, a=a, b=b, final=compare(quality(ra), quality(rb)),
                    common_fe=common, common=compare(at_fe(da, common), at_fe(db, common)),
                    quality_a=quality(ra), quality_b=quality(rb),
                    common_quality_a=at_fe(da, common), common_quality_b=at_fe(db, common)))
    summary = []
    for case in CASES:
        for method in METHODS:
            selected = [r for r in rows if r['case'] == case and r['method'] == method]
            summary.append(dict(case=case, method=method,
                q_general_median=median(r['quality'][0] for r in selected),
                q_lecturer_median=median(r['quality'][1] for r in selected),
                improved=sum(r['improved'] for r in selected),
                q_general_improved=sum(r['q_general_improved'] for r in selected),
                fe=sum(r['metrics']['fitness_evaluations'] for r in selected),
                decode_failures=sum(r['metrics']['decode_failed_count'] for r in selected),
                backtracks=sum(r['metrics']['total_decode_backtracks'] for r in selected)))


    baselines = []
    for case in CASES:
        prepared = prepare_snapshot_for_optimization(DATA/f'data/{case}.json')
        payload = read(result_path(case,SEEDS[0],BASELINE))
        detail = read(detail_path(case,SEEDS[0],BASELINE))
        check = read(checkpoint(case,SEEDS[0],BASELINE))
        assert check['result_sha'] == sha(result_path(case,SEEDS[0],BASELINE))
        assert check['detail_sha'] == sha(detail_path(case,SEEDS[0],BASELINE))
        assert payload['result']['metrics']['fitness_evaluations'] <= 1
        if payload['status'] == 'COMPLETED':
            audit(payload,prepared)
        baselines.append(dict(case=case,status=payload['status'],
            quality=quality(payload) if payload['status']=='COMPLETED' else None,
            metrics=payload['result']['metrics'],reason=payload.get('reason')))
    def outcome(a,b,kind,case=None):
        selected=[p for p in pairs if (p['a'],p['b']) in ((a,b),(b,a)) and (case is None or p['case']==case)]
        values=[]
        for p in selected:
            value=p[kind]
            if p['a']!=a:
                value=dict(win='loss',loss='win',tie='tie')[value]
            values.append(value)
        return values
    def tally(a,b,kind,case=None):
        count=Counter(outcome(a,b,kind,case))
        return [count['win'],count['tie'],count['loss']]
    tests=[]
    for kind in ('final','common'):
        family=[]
        for b in ('GA','PO','HYBRID50'):
            w,t,l=tally('ISLAND80',b,kind)
            pvalue=binomtest(w,w+l,.5).pvalue if w+l else 1.
            family.append(dict(a='ISLAND80',b=b,endpoint=kind,wins=w,ties=t,losses=l,p_raw=pvalue))
        order=sorted(range(len(family)),key=lambda i:family[i]['p_raw'])
        adjusted=0.
        for position,index in enumerate(order):
            adjusted=max(adjusted,min(1.,family[index]['p_raw']*(len(family)-position)))
            family[index]['p_holm']=adjusted
        tests.extend(family)
    ranks=[]
    for case in CASES:
        for seed in SEEDS:
            cohort={r['method']:r['quality'] for r in rows if r['case']==case and r['seed']==seed}
            for method in METHODS:
                scores=Counter(compare(cohort[method],cohort[b]) for b in METHODS if b!=method)
                ranks.append(dict(case=case,seed=seed,method=method,rank=1+scores['loss']+.5*scores['tie'],
                    wins=scores['win'],ties=scores['tie'],losses=scores['loss'],best=scores['loss']==0))
    save(out/'rows.json',rows)
    save(out/'pairs.json',pairs)
    save(out/'summary.json',summary)
    save(out/'initial_statistics.json',initial_statistics)
    save(out/'sign_tests.json',tests)
    save(out/'ranks.json',ranks)
    save(out/'baselines.json',baselines)
    save(out/'final_audit.json',dict(results=len(rows),checkpoints=len(rows),shared_cohorts=len(initial_statistics),
        baselines=len(baselines),hard_violations=0,soft_option_scores=0,
        full_fitness_entries_replay=True,source_verified=True,
        mechanism_sha=sha(ROOT/'source/islands.py')))
    assert len(rows)==EXPECTED_RUNS and len(initial_statistics)==len(CASES)*len(SEEDS)
    with (out/'summary.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(summary[0]))
        writer.writeheader()
        writer.writerows(summary)
    with (out/'raw_results.csv').open('w',encoding='utf-8-sig',newline='') as f:
        names=('case','seed','method','q_general','q_lecturer','fe','failures','backtracks','hard_violations')
        writer=csv.DictWriter(f,fieldnames=names)
        writer.writeheader()
        for r in rows:
            writer.writerow(dict(case=r['case'],seed=r['seed'],method=r['method'],
                q_general=r['quality'][0],q_lecturer=r['quality'][1],fe=r['metrics']['fitness_evaluations'],
                failures=r['metrics']['decode_failed_count'],backtracks=r['metrics']['total_decode_backtracks'],hard_violations=0))
    colors=dict(GA='#2864a4',PO='#c07818',HYBRID50='#8b6fb1',ISLAND80='#178260')
    for case in CASES:
        fig,axes=plt.subplots(2,2,figsize=(13,8))
        limit=min(results[case,s,m]['result']['metrics']['fitness_evaluations'] for s in SEEDS for m in METHODS)
        for method in METHODS:
            for component,field in enumerate(('general_quality_score','lecturer_preference_score')):
                values=np.array([[h[field] for h in results[case,s,method]['result']['convergence_history']] for s in SEEDS])
                x=np.arange(GENERATIONS+1)
                low,mid,high=np.quantile(values,[.25,.5,.75],axis=0)
                axes[component,0].plot(x,mid,label=method,color=colors[method])
                axes[component,0].fill_between(x,low,high,color=colors[method],alpha=.1)
                xfe=np.arange(POPULATION,limit+1)
                values=np.array([[at_fe(details[case,s,method],fe)[component] for fe in xfe] for s in SEEDS])
                low,mid,high=np.quantile(values,[.25,.5,.75],axis=0)
                axes[component,1].plot(xfe,mid,label=method,color=colors[method])
                axes[component,1].fill_between(xfe,low,high,color=colors[method],alpha=.1)
        for i,label in enumerate(('Q_general','Q_lecturer')):
            for j in (0,1):
                axes[i,j].set_ylabel(label+' (càng nhỏ càng tốt)')
                axes[i,j].set_xlabel('Vòng lặp' if j==0 else 'FE thực — miền chung')
                axes[i,j].grid(alpha=.2)
                axes[i,j].legend(fontsize=8)
        fig.suptitle(case.upper()+f' — Trung vị/IQR {len(SEEDS)} seed, N{POPULATION}/{GENERATIONS} vòng/trần{FE_CAP}FE')
        fig.tight_layout(rect=(0,0,1,.95))
        fig.savefig(out/f'{case}_convergence.png',dpi=160)
        plt.close(fig)
    fig,axes=plt.subplots(2,3,figsize=(15,8))
    for j,case in enumerate(CASES):
        for i,label in enumerate(('Q_general','Q_lecturer')):
            values=[[r['quality'][i] for r in rows if r['case']==case and r['method']==m] for m in METHODS]
            axes[i,j].boxplot(values,tick_labels=METHODS,showmeans=True)
            for k,ys in enumerate(values):
                axes[i,j].scatter([k+1]*len(ys),ys,color=colors[METHODS[k]],s=13,alpha=.65)
            baseline=next(b for b in baselines if b['case']==case)
            if baseline['quality'] is not None:
                axes[i,j].axhline(baseline['quality'][i],color='black',ls='--',label='Greedy (1 run)')
                axes[i,j].legend(fontsize=8)
            axes[i,j].set_title(case.upper()+' — '+label)
            axes[i,j].tick_params(axis='x',rotation=15)
            axes[i,j].grid(axis='y',alpha=.2)
    fig.tight_layout()
    fig.savefig(out/'quality_distribution.png',dpi=160)
    plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(12,4.5))
    opponents=('GA','PO','HYBRID50')
    for ax,kind in zip(axes,('final','common')):
        left=[0]*3
        for index,(label,color) in enumerate((('Thắng','#178260'),('Hòa','#c8c8c8'),('Thua','#bc4b47'))):
            numbers=[tally('ISLAND80',b,kind)[index] for b in opponents]
            ax.barh(opponents,numbers,left=left,color=color,label=label)
            for j,n in enumerate(numbers):
                if n: ax.text(left[j]+n/2,j,str(n),ha='center',va='center')
            left=[a+b for a,b in zip(left,numbers)]
        ax.set_xlim(0,len(CASES)*len(SEEDS))
        ax.set_title('Cuối 20 vòng' if kind=='final' else 'FE thực chung từng cặp')
        ax.legend()
    fig.suptitle('ISLAND80 so đối chứng — thắng/hòa/thua')
    fig.tight_layout()
    fig.savefig(out/'paired_comparison.png',dpi=160)
    plt.close(fig)
    fig,axes=plt.subplots(1,3,figsize=(14,4))
    for ax,case in zip(axes,CASES):
        for k,b in enumerate(opponents):
            deltas=[]
            for seed in SEEDS:
                a=quality(results[case,seed,'ISLAND80'])
                other=quality(results[case,seed,b])
                deltas.append(a[0]-other[0])
            ax.scatter([k]*len(deltas),deltas,label=b)
        ax.axhline(0,color='black',lw=.8)
        ax.set_xticks(range(3),opponents)
        ax.set_title(case.upper()+' — Δ Q_general')
        ax.set_ylabel('ISLAND80 − đối chứng; âm là tốt hơn')
    fig.tight_layout()
    fig.savefig(out/'paired_general_differences.png',dpi=160)
    plt.close(fig)
    fig,axes=plt.subplots(1,3,figsize=(14,4))
    for j,key in enumerate(('fitness_evaluations','decode_failed_count','total_decode_backtracks')):
        for method in METHODS:
            values=[sum(r['metrics'][key] for r in rows if r['case']==case and r['method']==method) for case in CASES]
            axes[j].plot(CASES,values,marker='o',label=method,color=colors[method])
        axes[j].set_title(key)
        axes[j].grid(alpha=.2)
        axes[j].legend(fontsize=8)
        if j: axes[j].set_yscale('symlog',linthresh=1)
    fig.tight_layout()
    fig.savefig(out/'search_cost_by_scale.png',dpi=160)
    plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11,4))
    for method in METHODS:
        for i,key in enumerate(('q_general_median','q_lecturer_median')):
            axes[i].plot(CASES,[next(s[key] for s in summary if s['case']==case and s['method']==method) for case in CASES],
                         marker='o',label=method,color=colors[method])
            axes[i].set_title(key)
            axes[i].grid(alpha=.2)
            axes[i].legend(fontsize=8)
    fig.suptitle('Ba fixture liên quan; điểm khác quy mô không phải cùng đề bài')
    fig.tight_layout()
    fig.savefig(out/'quality_by_scale.png',dpi=160)
    plt.close(fig)
    island_rows=[r for r in rows if r['method']=='ISLAND80']
    fig,axes=plt.subplots(1,2,figsize=(12,4))
    for ax,keys in zip(axes,(('ga_meaningful_improvements','po_meaningful_improvements'),
                            ('ga_to_po','po_to_ga','ga_parent_po_discovered'))):
        for key in keys:
            ax.plot(CASES,[sum(r['contributions']['counts'][key] for r in island_rows if r['case']==case) for case in CASES],
                    marker='o',label=key)
        ax.grid(alpha=.2)
        ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(out/'cooperation_contributions.png',dpi=160)
    plt.close(fig)
    from types import SimpleNamespace
    from gapo_timetabling.application.reporting import build_timetable_report_rows,_plot_detailed_timetable
    for case in CASES:
        ordered=sorted(SEEDS,key=lambda s:(quality(results[case,s,'ISLAND80']),s))
        chosen=ordered[(len(ordered)-1)//2]
        prepared=prepare_snapshot_for_optimization(DATA/f'data/{case}.json')
        replay=audit(results[case,chosen,'ISLAND80'],prepared)
        proxy=SimpleNamespace(best_individual=SimpleNamespace(selected_options=replay.selected_options))
        table=build_timetable_report_rows(prepared.problem,proxy)
        _plot_detailed_timetable(out/f'{case}_island80_timetable.png',table)
        save(out/f'{case}_timetable_source.json',dict(seed=chosen,selection='lower median lexicographic quality',
                                                   quality=quality(results[case,chosen,'ISLAND80'])))
    lines=['# D155 — Benchmark chính thức ISLAND80 trên dữ liệu stress D150','',
        f'Đủ{len(rows)}/{EXPECTED_RUNS} optimizer run, {len(initial_statistics)} sharedinitialcohort; tất cả best hard0.',
        'Giữ nguyên cơ chế D154, D153 encode/decode/Fitness; không áp dụng lai vào production.',
        'N30/20vòng/trần630FE, seed1–10, bốn optimizer; Greedy1lần/bộ.','',
        '## So ISLAND80 — thắng/hòa/thua','',
        '| Đối chứng | Small cuối | Medium cuối | Large cuối | Tổng cuối | Tổng FE chung |',
        '|---|---|---|---|---|---|']
    for b in opponents:
        cells=['/'.join(map(str,tally('ISLAND80',b,'final',c))) for c in CASES]
        lines.append('|'+b+'|'+'|'.join(cells)+'|'+'/'.join(map(str,tally('ISLAND80',b,'final')))+'|'+
                     '/'.join(map(str,tally('ISLAND80',b,'common')))+'|')
    lines+=['','## Hai Q trung vị riêng và chi phí','',
        '| Bộ | Method | Qg | QL | Best giảm/10 | FE thực | Decodefail | Backtrack |',
        '|---|---|---:|---:|---:|---:|---:|---:|']
    for s in summary:
        lines.append(f"|{s['case']}|{s['method']}|{s['q_general_median']:.6f}|{s['q_lecturer_median']:.6f}|{s['improved']}|{s['fe']}|{s['decode_failures']}|{s['backtracks']}|")
    lines+=['','## Kiểm định thăm dò','',
        '| Endpoint | So với | W/T/L | p raw | p Holm |','|---|---|---|---:|---:|']
    for t in tests:
        lines.append(f"|{t['endpoint']}|{t['b']}|{t['wins']}/{t['ties']}/{t['losses']}|{t['p_raw']:.6g}|{t['p_holm']:.6g}|")
    lines+=['','## Greedy (không kiểm định nhiều seed)','']
    for b in baselines:
        lines.append(f"- {b['case']}: {b['status']}, quality={b['quality']}, reason={b['reason']}.")
    lines+=['','## Giới hạn','',
        'Không nhận đây là holdout mù: các fixture liên quan đã được nghiên cứu nhiều lần.',
        'Không tính hòa thành thắng hoặc so hai trung vị riêng thay paired comparison.',
        'Không chạy RAND ablation trong đợt này; pilot RAND còn3/3 cuối run, không quy gain riêng PO.',
        'Runtime song song không dùng xếp hạng; FEcap không đồng nghĩa FE thực bằng nhau.',
        'Tất cả số liệu và ảnh từ savedJSON; không rerun optimizer để vẽ hoặc thay seed khi thua.',
        'Chưa chốt tích hợp lai mới; người dùng quyết định sau khi xem số liệu.',
        '', 'Chi tiết: analysis/rows.json,pairs.json,summary.json,sign_tests.json,ranks.json,baselines.json,final_audit.json.',
        'Ảnh: ba convergence,quality_distribution,paired_comparison,paired_general_differences,search_cost_by_scale,',
        'quality_by_scale,cooperation_contributions và ba thời khóa biểu từ seed trung vị.']
    (ROOT/'KET_QUA.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    verify()
    print('ANALYSIS_COMPLETE',dict(runs=len(rows),hard_violations=0),flush=True)


if __name__=='__main__':
    main()

