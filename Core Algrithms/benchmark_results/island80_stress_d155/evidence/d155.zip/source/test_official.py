"""Preflight for the official protocol, not an experiment result."""
from dataclasses import replace
from pathlib import Path

import pytest

import common
from islands import run_islands
from test_islands import inputs
from gapo_timetabling.core.hybrid import HybridConfig
from gapo_timetabling.core.population import initialize_population
from gapo_timetabling.core.greedy_baseline import run_greedy_first_feasible
from gapo_timetabling.core.constraints import validate_timetable


def test_protocol_and_exact_pilot_mechanism_identity():
    manifest=common.read(common.ROOT/'experiment.json')
    assert manifest['seeds']==list(common.SEEDS)==list(range(1,11))
    assert common.EXPECTED_RUNS==120 and len(common.METHODS)==4
    assert common.FE_CAP==630 and common.GENERATIONS==20 and common.POPULATION==30
    old=common.ROOT.parent/'island_priority_placement_20261101/source/islands.py'
    assert common.sha(old)==common.sha(common.ROOT/'source/islands.py')
    assert set(common.SEEDS).isdisjoint({111101,111102,110101,110102,110103})


def test_twenty_generations_share_one_budget_and_all_coordinates():
    p,domains,_,base=inputs()
    initial=initialize_population(p,domains,30,1000,42,base.evaluation_config)
    config=HybridConfig(630,5,43,base.evaluation_config)
    result,details=run_islands(p,domains,initial,config)
    c=details['counts']
    assert details['ga_size']==24 and details['po_size']==6
    assert c['ga_slots']==480 and c['po_slots']==120
    assert result.metrics.fitness_evaluations==30+c['ga_success']+c['po_success']<=630
    assert result.metrics.completed_iterations==20 and len(result.convergence_history)==21
    assert [e['generation'] for e in details['migrations']]==list(range(2,20,2))
    assert all(len(i.vector)==p.dimension for i in result.final_population)
    assert validate_timetable(p,result.best_individual.selected_options).is_valid


def test_baseline_is_deterministic_single_evaluation():
    p,domains,_,base=inputs()
    first=run_greedy_first_feasible(p,domains,base.evaluation_config)
    second=run_greedy_first_feasible(p,domains,base.evaluation_config)
    assert first.is_success and second.is_success
    assert first.individual==second.individual
    assert first.metrics.fitness_evaluations==1


def test_dense_trace_common_fe_comparison_does_not_pad():
    from analyze import at_fe
    short={'dense_trace':[dict(fe=1,best=[.2,.3]),dict(fe=2,best=[.1,.4])]}
    assert at_fe(short,2)==[.1,.4]
    with pytest.raises(IndexError):
        at_fe(short,3)
