"""Immutable experiment identities and atomic checkpoints, separate from production."""
from dataclasses import asdict
from hashlib import sha256
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT.parents[2]
DATA = ROOT.parent / 'scalability_stress_20261101'
CASES = ('small', 'medium', 'large')
SEEDS = tuple(range(1, 11))
METHODS = ('GA', 'PO', 'HYBRID50', 'ISLAND80')
BASELINE = 'GREEDY_FIRST_FEASIBLE'
EXPECTED_RUNS = len(CASES)*len(SEEDS)*len(METHODS)
FE_CAP = 630
GENERATIONS = 20
POPULATION = 30


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix+'.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
    temp.replace(path)


def canonical(value):
    return json.loads(json.dumps(value, default=str))


def sha(path):
    return sha256(Path(path).read_bytes()).hexdigest()


def digest(value):
    return sha256(json.dumps(canonical(value), sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def fingerprint():
    paths = list((PROJECT/'Core Algrithms/src').rglob('*.py'))+list((ROOT/'source').glob('*.py'))
    paths += [ROOT/'PROTOCOL.md', ROOT/'experiment.json',
              ROOT.parent/'island_priority_placement_20261101/source/islands.py']
    for case in CASES:
        paths += [DATA/f'configs/request_{case}.json', DATA/f'data/{case}.json']
    return dict(encoding='RECURRING_PRIORITY_PLACEMENT.v1', seeds=SEEDS, methods=METHODS,
        population=POPULATION, generations=GENERATIONS, fe_cap=FE_CAP,
        sha256={str(p.relative_to(PROJECT)): sha(p) for p in sorted(paths)},
        production_hybrid_unchanged=True)


def freeze():
    original = ROOT.parent/'island_priority_placement_20261101'
    assert sha(ROOT/'source/islands.py') == sha(original/'source/islands.py'), 'Hybrid mechanism drift'
    pilot = read(original/'provenance.json')
    key = str((original/'source/islands.py').relative_to(PROJECT))
    assert sha(ROOT/'source/islands.py') == pilot['sha256'][key]
    configured = read(ROOT/'experiment.json')
    assert configured['seeds'] == list(SEEDS) and configured['methods'] == list(METHODS)
    assert configured['population'] == POPULATION and configured['generations'] == GENERATIONS
    assert configured['fe_cap'] == FE_CAP and configured['planned_optimizer_runs'] == EXPECTED_RUNS
    value = canonical(fingerprint())
    path = ROOT/'provenance.json'
    if path.exists():
        assert read(path) == value, 'Frozen experiment changed; do not resume.'
    else:
        save(path, value)


def verify():
    assert read(ROOT/'provenance.json') == canonical(fingerprint()), 'Source/config/data changed.'


def result_path(case, seed, method):
    return ROOT/f'runs/{case}/{method}/seed_{seed}.json'


def detail_path(case, seed, method):
    return ROOT/f'details/{case}/{method}/seed_{seed}.json'


def checkpoint(case, seed, method):
    return ROOT/f'checkpoints/{case}/{method}/seed_{seed}.json'


def compare(a, b):
    for x, y in zip(a, b):
        if abs(x-y) > 1e-12:
            return 'win' if x < y else 'loss'
    return 'tie'


def audit(payload, prepared):
    from gapo_timetabling.core.placement_decoder import PlacementDecoder
    from gapo_timetabling.core.constraints import validate_timetable
    from gapo_timetabling.core.fitness import calculate_fitness
    p, domains = prepared.problem, prepared.option_domains
    solution = payload['result']['best_solution']
    engine = PlacementDecoder()
    result = engine(p, domains, tuple(solution['vector']), 20000)
    assert result.is_success and result.repaired_vector == tuple(solution['vector'])
    assert list(result.selected_option_indices) == solution['selected_option_indices']
    assert validate_timetable(p, result.selected_options).is_valid
    assert canonical(asdict(calculate_fitness(p, result.selected_options, domains))) == payload['result']['best_fitness']
    rows = []
    for o in result.selected_options:
        session, location = p.class_sessions[o.session_index], p.locations[o.location_index]
        rows.append(dict(class_session_id=session.class_session_id,
            lecturer_code=p.lecturers[p.option_lecturer_index(o)].lecturer_code,
            term_code=p.term.term_code, teaching_date=o.teaching_date.isoformat(),
            location_id=location.location_id, location_type=location.location_type.value,
            start_period=o.start_period, end_period=o.end_period))
    assert sorted(rows, key=lambda r: r['class_session_id']) == payload['result']['timetable_entries']
    assert engine.stats['soft_option_scores'] == 0
    return result
