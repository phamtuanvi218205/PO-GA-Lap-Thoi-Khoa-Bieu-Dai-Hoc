"""Independent method workers load one checksum-verified shared initial cohort."""
import argparse
from collections import Counter
from dataclasses import asdict, replace
from datetime import datetime
import pickle
from time import perf_counter

from common import (ROOT, DATA, CASES, SEEDS, METHODS, FE_CAP, GENERATIONS, POPULATION, BASELINE,
                    save, read, sha, digest, canonical, result_path, detail_path, checkpoint, verify, audit)
from islands import run_islands
from gapo_timetabling.application import run_contract
from gapo_timetabling.core import decoder, population
from gapo_timetabling.core.hybrid import HybridConfig
from gapo_timetabling.core.models import OptimizationAlgorithm
from gapo_timetabling.core.placement_decoder import PlacementDecoder
from gapo_timetabling.core.snapshot import prepare_snapshot_for_optimization


class ObservedDecoder(PlacementDecoder):
    def __init__(self):
        super().__init__()
        self.failure_reasons = Counter()
    def __call__(self, *args, **kwargs):
        result = super().__call__(*args, **kwargs)
        if not result.is_success:
            if 'vượt giới hạn' in result.reason:
                category = 'lecturer_overload'
            elif 'max_decode_nodes' in result.reason:
                category = 'node_budget'
            elif result.status.value == 'NO_OPTION':
                category = 'no_option'
            else:
                category = 'other_hard_failure'
            self.failure_reasons[category] += 1
        return result


def run(case, seed, method=None):
    verify()
    request = run_contract.load_run_request(DATA/f'configs/request_{case}.json')
    prepared = prepare_snapshot_for_optimization(request.snapshot.path, expected_checksum=request.snapshot.checksum)
    p, domains = prepared.problem, prepared.option_domains
    engine = ObservedDecoder()
    decoder.clear_decode_cache()
    decoder._PRIORITY_LOCAL.decoder = engine
    records, trace = [], []
    real_fitness = population.calculate_fitness
    def add(row):
        records.append(row)
        best = min((r['quality'] for r in records), key=tuple)
        trace.append(dict(fe=len(records), best=list(best)))
    def observe(*args, **kwargs):
        value = real_fitness(*args, **kwargs)
        add(dict(vector=list(engine.last_vector), quality=list(value.fitness_key),
                 phenotype=digest(args[1]), components=asdict(value.breakdown)))
        return value
    population.calculate_fitness = observe
    initial_path = ROOT/f'initial/{case}/seed_{seed}.json'
    object_path = initial_path.with_suffix('.pickle')
    try:
        if method == BASELINE:
            from gapo_timetabling.core.greedy_baseline import run_greedy_first_feasible
            if result_path(case, seed, method).exists() and detail_path(case, seed, method).exists():
                existing = read(result_path(case, seed, method))
                if existing['status'] == 'COMPLETED':
                    audit(existing, prepared)
            else:
                baseline = run_greedy_first_feasible(p, domains, request.evaluation_config)
                if baseline.is_success:
                    existing = run_contract.build_completed_result_payload(
                        request_id=f'd155-{case}-greedy', algorithm_name=BASELINE, prepared=prepared,
                        best_individual=baseline.individual, metrics=baseline.metrics,
                        convergence_history=baseline.convergence_history)
                    audit(existing, prepared)
                else:
                    existing = dict(status=baseline.status.value, algorithm=BASELINE,
                        solver_pipeline=decoder.DEFAULT_ENCODING, snapshot_checksum=prepared.snapshot_checksum,
                        reason=baseline.reason, result=dict(metrics=asdict(baseline.metrics)))
                assert len(records) == baseline.metrics.fitness_evaluations <= 1
                save(result_path(case, seed, method), existing)
                save(detail_path(case, seed, method), dict(records=records, dense_trace=trace,
                    decoder_work=dict(engine.stats), decoder_failure_reasons=dict(engine.failure_reasons),
                    status=baseline.status.value, reason=baseline.reason))
            verify()
            save(checkpoint(case, seed, method), dict(initial_sha=None,
                 result_sha=sha(result_path(case, seed, method)), detail_sha=sha(detail_path(case, seed, method)),
                 status=existing['status'], finished_at=datetime.now().isoformat()))
            print('BASELINE', case, existing['status'], flush=True)
            return
        if initial_path.exists():
            saved = read(initial_path)
            assert saved['pickle_sha256'] == sha(object_path)
            # Trusted local data created by this script, never downloaded pickles.
            initial = pickle.loads(object_path.read_bytes())
        else:
            assert method is None, 'Shared initialization missing.'
            last = [0.]
            def init_progress(value):
                if perf_counter()-last[0] > 5 or value.accepted_individual_count == POPULATION:
                    save(ROOT/f'progress/{case}_{seed}_initial.json', canonical(asdict(value)))
                    last[0] = perf_counter()
            started = perf_counter()
            initial = population.initialize_population(p, domains, POPULATION, 30000, seed,
                request.evaluation_config, progress_callback=init_progress)
            assert initial.is_success, initial.reason
            object_path.parent.mkdir(parents=True, exist_ok=True)
            temp = object_path.with_suffix('.tmp')
            temp.write_bytes(pickle.dumps(initial))
            temp.replace(object_path)
            saved = dict(seed=seed, case=case, dimension=p.dimension,
                initial_seconds=perf_counter()-started, records=records.copy(),
                initial_sha=digest([i.vector for i in initial.individuals]),
                pickle_sha256=sha(object_path), decoder_stats=dict(engine.stats),
                decoder_failure_reasons=dict(engine.failure_reasons))
            save(initial_path, saved)
        assert len(initial.individuals) == initial.fitness_evaluations == POPULATION
        assert saved['initial_sha'] == digest([i.vector for i in initial.individuals])
        assert [r['vector'] for r in saved['records']] == [list(i.vector) for i in initial.individuals]
        if method is None:
            print('INITIAL_READY', case, seed, flush=True)
            return
        # Resume only a fully saved result/detail pair, after independent replay.
        if result_path(case, seed, method).exists() and detail_path(case, seed, method).exists():
            existing, prior_detail = read(result_path(case, seed, method)), read(detail_path(case, seed, method))
            assert prior_detail['initial_sha'] == saved['initial_sha']
            audit(existing, prepared)
            assert existing['result']['metrics']['completed_iterations'] == GENERATIONS
            verify()
            save(checkpoint(case, seed, method), dict(initial_sha=saved['initial_sha'],
                 result_sha=sha(result_path(case, seed, method)), detail_sha=sha(detail_path(case, seed, method)),
                 hard_violations=0, resumed_saved_result=True, finished_at=datetime.now().isoformat()))
            print('REUSED_RESULT', case, seed, method, flush=True)
            return
        records.clear()
        trace.clear()
        for row in saved['records']:
            add(row)
        engine.reset_stats()
        engine.failure_reasons.clear()
        current = replace(request, population_size=POPULATION, max_fitness_evaluations=FE_CAP,
                          random_seed=seed, request_id=f'd155-{case}-{method}-{seed}')
        last = [0.]
        def progress(*values):
            if perf_counter()-last[0] > 5:
                save(ROOT/f'progress/{case}_{seed}_{method}.json',
                     dict(fe=len(records), best=trace[-1]['best'], at=datetime.now().isoformat()))
                last[0] = perf_counter()
        if method in ('ISLAND80', 'RAND_ISLAND80'):
            config = HybridConfig(FE_CAP, 5, seed, request.evaluation_config)
            result, contributions = run_islands(p, domains, initial, config,
                random_control=method == 'RAND_ISLAND80', progress_callback=progress)
        else:
            algorithm = OptimizationAlgorithm.GA_PO if method == 'HYBRID50' else OptimizationAlgorithm(method)
            result = run_contract._run_optimizer(replace(current, algorithm=algorithm),
                                                p, domains, initial, progress_callback=progress)
            contributions = None
        assert result.metrics.completed_iterations == GENERATIONS
        assert len(records) == result.metrics.fitness_evaluations <= FE_CAP
        assert trace[-1]['best'] == list(result.best_individual.fitness_key)
        work = dict(engine.stats)
        assert work['soft_option_scores'] == work['pattern_features_built'] == 0
        payload = run_contract.build_completed_result_payload(request_id=current.request_id,
            algorithm_name=method, prepared=prepared, best_individual=result.best_individual,
            metrics=result.metrics, convergence_history=result.convergence_history)
        replay = audit(payload, prepared)
        save(result_path(case, seed, method), payload)
        save(detail_path(case, seed, method), dict(initial_sha=saved['initial_sha'],
            records=records, dense_trace=trace, decoder_work=work,
            decoder_failure_reasons=dict(engine.failure_reasons), contributions=contributions,
            hard_violations=0, best_replay_nodes=replay.nodes_explored))
        verify()
        save(checkpoint(case, seed, method), dict(initial_sha=saved['initial_sha'],
             result_sha=sha(result_path(case, seed, method)), detail_sha=sha(detail_path(case, seed, method)),
             hard_violations=0, finished_at=datetime.now().isoformat()))
        print('DONE', case, seed, method, result.best_individual.fitness_key, flush=True)
    finally:
        population.calculate_fitness = real_fitness
        decoder.clear_decode_cache()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--case', choices=CASES, required=True)
    parser.add_argument('--seed', type=int, choices=SEEDS, required=True)
    parser.add_argument('--method', choices=METHODS+(BASELINE,))
    args = parser.parse_args()
    run(args.case, args.seed, args.method)
