"""RAM-aware independent workers; resume preserves finished results."""
from collections import deque
from datetime import datetime
import os
import subprocess
import sys
from time import monotonic, sleep
import psutil

from common import ROOT, PROJECT, CASES, SEEDS, METHODS, BASELINE, EXPECTED_RUNS, save, read, sha, freeze, verify, checkpoint

VALIDATED = set()


def valid_checkpoint(case, seed, method):
    key = (case, seed, method)
    if key in VALIDATED:
        return True
    path = checkpoint(case, seed, method)
    if not path.exists():
        return False
    value = read(path)
    valid = (value['result_sha'] == sha(ROOT/f'runs/{case}/{method}/seed_{seed}.json')
             and value['detail_sha'] == sha(ROOT/f'details/{case}/{method}/seed_{seed}.json'))
    if valid:
        VALIDATED.add(key)
    return valid


def main():
    lock = ROOT/'controller.lock'
    if lock.exists():
        old_pid = int(lock.read_text().strip())
        try:
            command = psutil.Process(old_pid).cmdline()
        except psutil.Error:
            command = []
        if any(str(ROOT/'source/controller.py').lower() == arg.lower() for arg in command):
            raise RuntimeError('This controller is already running.')
        lock.unlink()
    with lock.open('x') as handle:
        handle.write(str(os.getpid()))
    limit = min(16, psutil.cpu_count() or 1)
    reserve, estimate = int(1.5*1024**3), 256*1024**2
    peak_rss = 0
    env = dict(os.environ, PYTHONPATH=os.pathsep.join((str(PROJECT/'Core Algrithms/src'), str(ROOT/'source'))),
        PYTHONIOENCODING='utf-8', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
        MKL_NUM_THREADS='1', NUMEXPR_NUM_THREADS='1')
    state = dict(status='STARTING', pid=os.getpid(), started_at=datetime.now().isoformat(),
        planned_run_count=EXPECTED_RUNS, planned_baseline_count=len(CASES),
        max_workers=limit, peak_active_workers=0, jobs={},
        hardware=dict(logical_cpus=psutil.cpu_count(), physical_cpus=psutil.cpu_count(logical=False),
                      total_memory=psutil.virtual_memory().total))
    initial_pending = deque((c,s,None) for s in SEEDS for c in reversed(CASES))
    ready = deque((c,SEEDS[0],BASELINE) for c in CASES
                  if not valid_checkpoint(c,SEEDS[0],BASELINE))
    active, resources = {}, []
    started = monotonic()
    last_launch = last_sample = 0.
    try:
        freeze()
        psutil.cpu_percent(None)
        state['status'] = 'RUNNING'
        while initial_pending or ready or active:
            rss = []
            for key,(child,log,job) in list(active.items()):
                code = child.poll()
                if code is None:
                    try:
                        size = psutil.Process(child.pid).memory_info().rss
                        rss.append(size)
                        peak_rss = max(peak_rss,size)
                    except psutil.Error:
                        pass
                    continue
                active.pop(key)
                log.close()
                state['jobs'][key].update(status='COMPLETED' if code==0 else 'FAILED',exit_code=code)
                if code:
                    raise RuntimeError('Failed worker retained: '+key+'; see log. No automatic rerun.')
                case,seed,method = job
                if method is None:
                    for name in METHODS:
                        if not valid_checkpoint(case,seed,name):
                            ready.append((case,seed,name))
                print('FINISHED',key,flush=True)
            now = monotonic()
            if peak_rss:
                estimate = max(192*1024**2,int(peak_rss*1.5))
            available = psutil.virtual_memory().available
            headroom = available-sum(max(0,estimate-r) for r in rss)
            warm = len(state['jobs'])>=2 and now-started<15
            can_launch = (len(active)<limit and headroom>reserve+estimate and
                          now-last_launch>=.75 and not warm)
            if can_launch and (initial_pending or ready):
                initializing = sum(job[2] is None for _,_,job in active.values())
                if initial_pending and (initializing<min(6,limit) or not ready):
                    job = initial_pending.popleft()
                else:
                    job = ready.popleft()
                case,seed,method = job
                key=f'{case}/{seed}/{method or "initial"}'
                logpath=ROOT/f'logs/{case}_{seed}_{method or "initial"}.log'
                logpath.parent.mkdir(exist_ok=True)
                log=logpath.open('a',encoding='utf-8')
                command=[sys.executable,'-u',str(ROOT/'source/run_case.py'),'--case',case,'--seed',str(seed)]
                if method:
                    command+=['--method',method]
                child=subprocess.Popen(command,cwd=PROJECT,env=env,stdout=log,stderr=subprocess.STDOUT,
                    creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                active[key]=child,log,job
                state['jobs'][key]=dict(status='RUNNING',pid=child.pid,command=command,log=str(logpath))
                state['peak_active_workers']=max(state['peak_active_workers'],len(active))
                last_launch=now
                print('START',key,child.pid,flush=True)
            state.update(active_workers=len(active),pending_initial=len(initial_pending),pending_methods=len(ready),
                completed_run_count=sum(valid_checkpoint(c,s,m) for c in CASES for s in SEEDS for m in METHODS),
                completed_baseline_count=sum(valid_checkpoint(c,SEEDS[0],BASELINE) for c in CASES),
                completed_cohorts=sum((ROOT/f'initial/{c}/seed_{s}.json').exists() for c in CASES for s in SEEDS),
                available_memory=available,worker_rss_estimate=estimate)
            save(ROOT/'status.json',state)
            if now-last_sample>10:
                resources.append(dict(at=datetime.now().isoformat(),active_workers=len(active),
                    cpu_percent=psutil.cpu_percent(None),available_memory=available,
                    worker_rss_max=max(rss,default=0),worker_estimate=estimate))
                save(ROOT/'resources.json',resources)
                last_sample=now
            sleep(1)
        verify()
        assert state['completed_run_count']==EXPECTED_RUNS
        assert state['completed_baseline_count']==len(CASES)
        state['status']='ANALYZING'
        save(ROOT/'status.json',state)
        subprocess.run([sys.executable,'-u',str(ROOT/'source/analyze.py')],cwd=PROJECT,env=env,check=True)
        state.update(status='COMPLETED',finished_at=datetime.now().isoformat(),elapsed_seconds=monotonic()-started)
    except BaseException as error:
        for child,log,_ in active.values():
            if child.poll() is None:
                child.terminate()
                child.wait()
            log.close()
        state.update(status='FAILED',error=repr(error),finished_at=datetime.now().isoformat())
        raise
    finally:
        save(ROOT/'status.json',state)
        lock.unlink(missing_ok=True)


if __name__=='__main__':
    main()

