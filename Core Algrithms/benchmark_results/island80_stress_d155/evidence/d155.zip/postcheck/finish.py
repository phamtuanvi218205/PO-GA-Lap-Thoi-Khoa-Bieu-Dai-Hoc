"""Post-run read-only optimizer audit. Never imports or invokes an optimizer."""
from collections import Counter
from dataclasses import asdict
from itertools import combinations
from statistics import mean, median

from common import (ROOT, DATA, CASES, SEEDS, METHODS, BASELINE, read, save,
                    sha, digest, verify, canonical)
from gapo_timetabling.core.snapshot import prepare_snapshot_for_optimization
from gapo_timetabling.core.placement_decoder import PlacementDecoder
from gapo_timetabling.core.constraints import validate_timetable
from gapo_timetabling.core.fitness import calculate_fitness


def cmp(a, b):
    for x, y in zip(a, b):
        if abs(x-y) > 1e-12:
            return 'win' if x < y else 'loss'
    return 'tie'


def replay(payload, prepared):
    p, domains = prepared.problem, prepared.option_domains
    solution = payload['result']['best_solution']
    decoder = PlacementDecoder()
    decoded = decoder(p, domains, tuple(solution['vector']), 20000)
    assert decoded.is_success
    assert decoded.repaired_vector == tuple(solution['vector'])
    assert list(decoded.selected_option_indices) == solution['selected_option_indices']
    assert validate_timetable(p, decoded.selected_options).is_valid
    assert len(decoded.selected_options) == len(p.class_sessions)
    assert canonical(asdict(calculate_fitness(p, decoded.selected_options, domains))) == payload['result']['best_fitness']
    entries = []
    for option in decoded.selected_options:
        entries.append(dict(
            class_session_id=p.class_sessions[option.session_index].class_session_id,
            lecturer_code=p.lecturers[p.option_lecturer_index(option)].lecturer_code,
            term_code=p.term.term_code, teaching_date=option.teaching_date.isoformat(),
            location_id=p.locations[option.location_index].location_id,
            location_type=p.locations[option.location_index].location_type.value,
            start_period=option.start_period, end_period=option.end_period))
    assert sorted(entries, key=lambda r: r['class_session_id']) == payload['result']['timetable_entries']
    assert decoder.stats['soft_option_scores'] == 0


def main():
    verify()
    rows = read(ROOT/'analysis/rows.json')
    pairs = read(ROOT/'analysis/pairs.json')
    assert len(rows) == 120 and len(pairs) == 180
    assert len(list((ROOT/'runs').rglob('*.json'))) == 123
    assert len(list((ROOT/'checkpoints').rglob('*.json'))) == 123
    loaded = {}
    for case in CASES:
        prepared = prepare_snapshot_for_optimization(DATA/f'data/{case}.json')
        for seed in SEEDS:
            initial = read(ROOT/f'initial/{case}/seed_{seed}.json')
            assert len(initial['records']) == 30
            assert digest([r['vector'] for r in initial['records']]) == initial['initial_sha']
            assert initial['pickle_sha256'] == sha(ROOT/f'initial/{case}/seed_{seed}.pickle')
            for method in METHODS:
                rpath = ROOT/f'runs/{case}/{method}/seed_{seed}.json'
                dpath = ROOT/f'details/{case}/{method}/seed_{seed}.json'
                result, detail = read(rpath), read(dpath)
                checkpoint = read(ROOT/f'checkpoints/{case}/{method}/seed_{seed}.json')
                assert checkpoint['result_sha'] == sha(rpath)
                assert checkpoint['detail_sha'] == sha(dpath)
                assert checkpoint['initial_sha'] == detail['initial_sha'] == initial['initial_sha']
                assert detail['records'][:30] == initial['records']
                metric = result['result']['metrics']
                assert metric['completed_iterations'] == 20
                assert len(detail['records']) == len(detail['dense_trace']) == metric['fitness_evaluations'] <= 630
                best = None
                for i, record in enumerate(detail['records']):
                    if best is None or tuple(record['quality']) < tuple(best):
                        best = record['quality']
                    assert detail['dense_trace'][i] == dict(fe=i+1, best=best)
                quality = [result['result']['best_fitness'][k] for k in
                           ('general_quality_score', 'lecturer_preference_score')]
                assert best == quality
                history = result['result']['convergence_history']
                assert [h['iteration'] for h in history] == list(range(21))
                assert history[-1]['fitness_evaluations'] == metric['fitness_evaluations']
                assert detail['decoder_work']['soft_option_scores'] == 0
                replay(result, prepared)
                loaded[case, seed, method] = detail
            for a, b in combinations(METHODS, 2):
                da, db = loaded[case, seed, a], loaded[case, seed, b]
                fe = min(len(da['records']), len(db['records']))
                pair = next(p for p in pairs if (p['case'],p['seed'],p['a'],p['b']) == (case,seed,a,b))
                assert pair['common_fe'] == fe
                assert pair['common'] == cmp(da['dense_trace'][fe-1]['best'],db['dense_trace'][fe-1]['best'])
                assert pair['final'] == cmp(da['dense_trace'][-1]['best'],db['dense_trace'][-1]['best'])
        rp = ROOT/f'runs/{case}/{BASELINE}/seed_1.json'
        dp = ROOT/f'details/{case}/{BASELINE}/seed_1.json'
        cp = read(ROOT/f'checkpoints/{case}/{BASELINE}/seed_1.json')
        assert cp['result_sha'] == sha(rp) and cp['detail_sha'] == sha(dp)
        baseline = read(rp)
        if baseline['status'] == 'COMPLETED':
            replay(baseline, prepared)
    totals, ranks = {}, {}
    rank_rows = read(ROOT/'analysis/ranks.json')
    for method in METHODS:
        selected = [r for r in rows if r['method'] == method]
        totals[method] = {k: sum(r['metrics'][k] for r in selected) for k in
                         ('fitness_evaluations','candidate_attempts','decode_failed_count','total_decode_backtracks')}
        totals[method].update(improved=sum(r['improved'] for r in selected),
            q_general_improved=sum(r['q_general_improved'] for r in selected),
            fe_min=min(r['metrics']['fitness_evaluations'] for r in selected),
            fe_max=max(r['metrics']['fitness_evaluations'] for r in selected))
        rr = [r for r in rank_rows if r['method'] == method]
        ranks[method] = dict(average_rank=mean(r['rank'] for r in rr),
            best_cohorts=sum(r['best'] for r in rr),pair_wins=sum(r['wins'] for r in rr))
    contribution, behaviors = Counter(), Counter()
    for r in rows:
        if r['method'] == 'ISLAND80':
            contribution.update(r['contributions']['counts'])
            behaviors.update(r['contributions']['behaviors'])
    comparisons = {}
    for endpoint in ('final','common'):
        comparisons[endpoint] = {}
        for opponent in ('GA','PO','HYBRID50'):
            sizes = {}
            for case in (*CASES, 'all'):
                counts = Counter()
                for p in pairs:
                    if {p['a'],p['b']} != {'ISLAND80',opponent} or (case != 'all' and p['case'] != case):
                        continue
                    outcome = p[endpoint]
                    if p['a'] != 'ISLAND80':
                        outcome = dict(win='loss',loss='win',tie='tie')[outcome]
                    counts[outcome] += 1
                sizes[case] = [counts[k] for k in ('win','tie','loss')]
            comparisons[endpoint][opponent] = sizes
    initial_stats = read(ROOT/'analysis/initial_statistics.json')
    resources = read(ROOT/'resources.json')
    output = dict(results=120,checkpoints=123,cohorts=30,baseline_replays=3,
        full_replay_hard0=True,full_coverage=True,soft_queries=0,source_unchanged=True,
        mechanism_matches_pilot=True,optimizer_reruns=0,totals=totals,ranks_final=ranks,
        comparisons=comparisons,contributions=dict(contribution),behaviors=dict(behaviors),
        initial_qg_std_range=[min(r['q_general_std'] for r in initial_stats),max(r['q_general_std'] for r in initial_stats)],
        initial_ql_std_range=[min(r['q_lecturer_std'] for r in initial_stats),max(r['q_lecturer_std'] for r in initial_stats)],
        initial_unique_phenotypes_range=[min(r['unique_phenotypes'] for r in initial_stats),max(r['unique_phenotypes'] for r in initial_stats)],
        peak_cpu_percent=max(r['cpu_percent'] for r in resources),
        minimum_available_ram_bytes=min(r['available_memory'] for r in resources))
    verify()
    save(ROOT/'analysis/independent_audit.json',output)
    print(output,flush=True)


if __name__ == '__main__':
    main()
